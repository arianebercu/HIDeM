
### Code:
##' @title Log likelihood with weibull baseline risk
##' @param b  parameters not fixed
##' @param npm  number of parameters not fixed
##' @param npar number of parameters
##' @param bfix parameters fixed
##' @param fix indicators of fixed and unfixed parameters
##' @param ctime classification of subject according to their observations
##' @param no number of subjects
##' @param ve01 variables for transition 0 -->1 
##' @param ve02 variables for transition 0 -->2
##' @param ve12 variables for transition 1 -->2
##' @param dimnva01 number of variables for transition 0 -->1 
##' @param dimnva02 number of variables for transition 0 -->2
##' @param dimnva12 number of variables for transition 1 -->2
##' @param nva01 number of variables for transition 0 -->1 
##' @param nva02 number of variables for transition 0 -->2
##' @param nva12 number of variables for transition 1 -->2
##' @param t0 time entry
##' @param t1 time L
##' @param t2 time R
##' @param t3 time of event/out
##' @param troncature indicator if troncature or not
##' @param gausspoint number of gausspoint quadrature
##' @param weib the form of the weibull parameters 
#' @useDynLib HIDeM
##' @export
#' @author R: Ariane Bercu <ariane.bercu@@u-bordeaux.fr> 
#' 
DYNidmlLikelihoodweib<-function(b,npm,npar,bfix,fix,ctime,no,ve01,ve02,ve12,
                                dimnva01,dimnva02,dimnva12,nva01,nva02,nva12,
                                t0,t1,t2,t3,troncature,
                                y01,y02,y12,p01,p02,p12,
                                dimp01,dimp02,dimp12,Ntime,time){
  res<-0

  .Fortran("idmlikelihoodweibtimedepgrid",
           ## input
           as.double(b),
           as.integer(npm),
           as.integer(npar),
           as.double(bfix),
           as.integer(fix),
           as.integer(ctime),
           as.integer(no),
           as.double(ve01),
           as.double(ve12),
           as.double(ve02),
           as.double(y01),
           as.double(y02),
           as.double(y12),
           as.integer(p01),
           as.integer(p02),
           as.integer(p12),
           as.integer(dimp01),
           as.integer(dimp02),
           as.integer(dimp12),
           as.integer(Ntime),
           as.double(time),
           as.integer(dimnva01),
           as.integer(dimnva12),
           as.integer(dimnva02),
           as.integer(nva01),
           as.integer(nva12),
           as.integer(nva02),
           as.double(t0),
           as.double(t1),
           as.double(t2),
           as.double(t3),
           as.integer(troncature),
           likelihood_res=as.double(res),
           PACKAGE="HIDeM")$likelihood_res
}


gaussDYNidmlLikelihoodweib<-function(b,npm,npar,bfix,fix,ctime,no,ve01,ve02,ve12,
                                dimnva01,dimnva02,dimnva12,nva01,nva02,nva12,
                                t0,t1,t2,t3,troncature,
                                y01,y02,y12,p01,p02,p12,
                                dimp01,dimp02,dimp12,Ntime){
  
  #browser()
  
  res<-0
  .Fortran("idmlikelihoodweibtimedep",
           ## input
           as.double(b),
           as.integer(npm),
           as.integer(npar),
           as.double(bfix),
           as.integer(fix),
           as.integer(ctime),
           as.integer(no),
           as.double(ve01),
           as.double(ve12),
           as.double(ve02),
           as.double(y01),
           as.double(y02),
           as.double(y12),
           as.integer(p01),
           as.integer(p02),
           as.integer(p12),
           as.integer(dimp01),
           as.integer(dimp02),
           as.integer(dimp12),
           as.integer(Ntime),
           as.integer(dimnva01),
           as.integer(dimnva12),
           as.integer(dimnva02),
           as.integer(nva01),
           as.integer(nva12),
           as.integer(nva02),
           as.double(t0),
           as.double(t1),
           as.double(t2),
           as.double(t3),
           as.integer(troncature),
           likelihood_res=as.double(res),
           PACKAGE="HIDeM")$likelihood_res
}






